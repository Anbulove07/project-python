import eel
import time
from datetime import datetime

# Sample data for default class and institute name
DEFAULT_CLASS = "5th Grade"
INSTITUTE_NAME = "ABC Academy"


# Function to read user data from a text file
def read_user_data(file_path):
    user_list = []
    with open(file_path, 'r') as file:
        for line in file:
            name, user_id, mobile, grade = line.strip().split(',')
            user_list.append({
                'name': name,
                'id': int(user_id),
                'mobile': mobile,
                'grade': grade
            })
    return user_list


# Load user data from the text file
user_list = read_user_data('users.txt')


# Function to send SMS (simulated)
def send_sms(user):
    time.sleep(1)  # Simulating delay for sending SMS
    print(
        f"SMS sent to {user['name']} (ID: {user['id']}): Status - {user['status']}, Remarks - {user['remarks']}, Mobile - {user['mobile']}")


# Update status list and send SMS
@eel.expose
def update_status_list(user_status_list):
    for user in user_status_list:
        # Create a formatted remark based on the status
        if user['status'] == 'Absent':
            current_date = datetime.now().strftime("%Y-%m-%d")  # Get current date
            user['remarks'] = user['remarks'] if user[
                'remarks'] else f"Dear parent, your child {user['name']} of {user['grade']} is absent on {current_date}. Please send your child regularly – {INSTITUTE_NAME}"


        
        send_sms(user)  # Call the SMS sending function here
    return "Status updated and SMS sent!"


# Function to get the user list
@eel.expose
def get_user_list():
    return user_list


# Start the Eel application
eel.init('web')
eel.start('index.html', size=(800, 600))
